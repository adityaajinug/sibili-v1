<div class="container-fluid">
  <div class="row">
    <div class="col-md-3 col-12 coloumn col-5">
      <div class="desc-time">
        <span class="time">12:00 - 16:00</span>
      </div>
    </div>
    <div class="col-md-9">
      <div class="card card-attandance shadow-sm">
        <div class="card-body body-attandance d-md-flex align-items-center">
          <div class="attandance-desc">
            <h5>Bimbingan Pertama</h5>
            <p>12 Mei 2020</p>
            <div class="btn-attandance">
              <button class="btn btn-blue">Absen</button>
            </div>
          </div>

          <div class="icon-attandance ml-auto">
            <i class="fas fa-signature"></i>
          </div>

        </div>
      </div>
    </div>
  </div>
  <div class="row mt-5">
    <div class="col-md-3 col-12 coloumn col-5">
      <div class="desc-time">
        <span class="time">8:00 - 16:00</span>
      </div>
    </div>
    <div class="col-md-9">
      <div class="card card-attandance shadow-sm">
        <div class="card-body body-attandance d-md-flex align-items-center">
          <div class="attandance-desc">
            <h5>Bimbingan Pertama</h5>
            <p>12 Mei 2020</p>
            <div class="btn-attandance">
              <button class="btn btn-blue">Absen</button>
            </div>
          </div>

          <div class="icon-attandance ml-auto">
            <i class="fas fa-signature"></i>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>