<div class="container-fluid">
  <div class="row">
    <div class="col-md-4">
      <div class="card card-total-file shadow-sm">
        <div class="card-body body-total-file d-flex align-items-center">
          <div class="text-total-file">
            <span class="sum">8</span>
            <p class="desc">Mahasiswa Bimbingan</p>
          </div>
          <div class="icon-total-file">
            <i class="fas fa-file-alt"></i>
          </div>

        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card card-total-file shadow-sm">
        <div class="card-body body-total-file d-flex align-items-center">
          <div class="text-total-file">
            <span class="sum">5</span>
            <p class="desc">File Laporan</p>
          </div>
          <div class="icon-total-file">
            <i class="fas fa-file-pdf"></i>
          </div>

        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card card-total-file shadow-sm">
        <div class="card-body body-total-file d-flex align-items-center">
          <div class="text-total-file">
            <span class="sum">1</span>
            <p class="desc">File Proposal</p>
          </div>
          <div class="icon-total-file">
            <i class="fas fa-file-word"></i>
          </div>

        </div>
      </div>
    </div>
  </div>