<div class="container-fluid">
  <div class="row">
    <div class="col-md-3">
      <div class="card card-folder mt-4">
        <div class="card-body card-body-folder">
          <i class="fas fa-folder"></i>
          <div class="card-text file-text">2019 / 2020</div>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <a href="<?= base_url('referensi/file_detail') ?>">
        <div class="card card-folder mt-4">
          <div class="card-body card-body-folder">
            <i class="fas fa-folder"></i>
            <div class="card-text file-text">2019 / 2020</div>
          </div>
        </div>
      </a>
    </div>
    <div class="col-md-3">
      <div class="card card-folder mt-4">
        <div class="card-boay card-body-folder">
          <i class="fas fa-folder"></i>
          <div class="card-text file-text">2019 / 2020</div>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card card-folder mt-4">
        <div class="card-body card-body card-body-folder">
          <i class="fas fa-folder"></i>
          <div class="card-text file-text">2019 / 2020</div>
        </div>
      </div>
    </div>
  </div>