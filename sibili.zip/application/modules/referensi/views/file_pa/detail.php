<div class="container-fluid">
  <div class="row">
    <div class="col-md-4">
      <div class="card card-file shadow-lg">
        <div class="card-body card-body-file">
          <div class="icon-file">
            <i class="fas fa-file-pdf"></i>
          </div>
          <div class="card-text text-file">A22.2019.02756</div>
          <div class="action">
            <div class="description">
              <p class="text-size">File Size :</p>
              <p class="file-size">8.62MB</p>
            </div>
            <div class="download">
              <button class="btn btn-download"> <i class="fas fa-download"></i></button>

            </div>
          </div>

        </div>
      </div>

    </div>
    <div class="col-md-4">
      <div class="card card-file shadow-lg">
        <div class="card-body card-body-file">
          <div class="icon-file">
            <i class="fas fa-file-pdf"></i>
          </div>
          <div class="card-text text-file">A22.2019.02756</div>
          <div class="action">
            <div class="description">
              <p class="text-size">File Size :</p>
              <p class="file-size">8.62MB</p>
            </div>
            <div class="download">
              <button class="btn btn-download"> <i class="fas fa-download"></i></button>

            </div>
          </div>

        </div>
      </div>

    </div>
    <div class="col-md-4">
      <div class="card card-file shadow-lg">
        <div class="card-body card-body-file">
          <div class="icon-file">
            <i class="fas fa-file-pdf"></i>
          </div>
          <div class="card-text text-file">A22.2019.02756</div>
          <div class="action">
            <div class="description">
              <p class="text-size">File Size :</p>
              <p class="file-size">8.62MB</p>
            </div>
            <div class="download">
              <button class="btn btn-download"> <i class="fas fa-download"></i></button>

            </div>
          </div>

        </div>
      </div>

    </div>
  </div>