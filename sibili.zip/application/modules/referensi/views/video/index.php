<div class="container-fluid">
  <div class="row">
    <div class="col-12">

      <div class="row">


        <div class="col-lg-4 col-md-6">

          <div class="card shadow-lg" style="border-radius: 20px;height:90%">
            <iframe height="300" src="https://www.youtube.com/embed/BdPkjdsnviw" title=" YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            <div class="card-body">
              <h4 class="card-title">Cara membuat Latar Belakang</h4>


            </div>
          </div>

        </div>
      </div>
    </div>
  </div>