<div class="container-fluid">

  <div class="row">
    <div class="col-md-6">
      <div class="card file-show">
        <div class="card-body file-show-box">
          <?php if ($detailbab['file'] > 0) { ?>
            <div id="adobe-dc-view"></div>
          <?php } else if ($detailbab['file'] < 0) {  ?>
            <p style="display:flex;justify-content:center;margin:auto;font-size:20px">Belum upload file</p>
          <?php
          } ?>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card chat">
        <div class="block">
          <div class="user-block">
            <div class="user-img">
              <img src="<?= base_url('assets/vendor/images/users/agent.jpg') ?>" alt="" srcset="">
            </div>
            <div class="user-desc">
              <ol>
                <li class="name">Edi Sugiarto, S.Kom, M.Kom</li>
                <li class="circle-offline"></li>
                <li class="status">Offline</li>
              </ol>
            </div>

          </div>
          <!-- <div class="icon-addon">
            <button class="btn-menu-add" id="btn-dropdown"><i class="fas fa-ellipsis-v"></i></button>
            <div id="dropdown-btn" class="dropdown-menu-add">
              <a href="#home" class="upload">Upload File <input type="file" class="input-file"></a>
              <a href="#about">Media</a>
              <a href="#contact">Links</a>
            </div>

          </div> -->
        </div>


        <div class="body-box">
          <div class="chat-box">
            <div class="chat-left">
              <div class="message">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, suscipit at?</p>
              </div>
              <div class="chat-time">
                <p>10.30 am</p>
              </div>
            </div>
            <div class="chat-right">
              <div class="message">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, suscipit at?</p>
              </div>
              <div class="chat-time">
                <p>10.30 am</p>
              </div>
            </div>
            <div class="chat-left">
              <div class="message">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, suscipit at?</p>
              </div>
              <div class="chat-time">
                <p>10.30 am</p>
              </div>
            </div>
            <div class="chat-right">
              <div class="message">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, suscipit at?</p>
              </div>
              <div class="chat-time">
                <p>10.30 am</p>
              </div>
            </div>
            <div class="chat-left">
              <div class="message">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, suscipit at?</p>
              </div>
              <div class="chat-time">
                <p>10.30 am</p>
              </div>
            </div>
            <div class="chat-right">
              <div class="message">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, suscipit at?</p>
              </div>
              <div class="chat-time">
                <p>10.30 am</p>
              </div>
            </div>

          </div>
        </div>
        <div class="typing-message">
          <form class="typing">
            <textarea placeholder="Ketik Pesan" rows="2"></textarea>
            <button class="btn btn-send"><i class="fas fa-paper-plane"></i></button>
          </form>
        </div>



      </div>
    </div>
  </div>