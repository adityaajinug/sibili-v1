<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card shadow-lg">
                <div class="card-body">
                    <h4 class="card-title">Tambah Data Dosen Pembiming</h4>

                    <form class="mt-4">
                        <div class="form-group">
                            <label for="kelompok">Kelompok</label>
                            <input type="text" class="form-control" id="kelompok" placeholder="DTI232" readonly>
                        </div>
                        <div class="form-group">
                            <label for="dosen_pembimbing">Dosen Pembimbing</label>
                            <input type="text" class="form-control" id="dosen_pembimbing" placeholder="Dosen Pembimbing">
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>